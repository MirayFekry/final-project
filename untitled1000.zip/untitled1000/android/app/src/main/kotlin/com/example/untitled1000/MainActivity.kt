package com.example.untitled1000

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
