import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class EditProfileForm extends StatefulWidget {
  final User user;

  EditProfileForm({required this.user});

  @override
  _EditProfileFormState createState() => _EditProfileFormState();
}

class _EditProfileFormState extends State<EditProfileForm> {
  final _formKey = GlobalKey<FormState>();
  User user;
  File _profileImage;

  @override
  void initState() {
    super.initState();
    user = widget.user;
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: Column(
        children: <Widget>[
          CircleAvatar(
            radius: 50.0,
            backgroundImage: _profileImage == null
                ? NetworkImage(user.profileImageUrl)
                : FileImage(_profileImage),
          ),
          RaisedButton(
            onPressed: () {
              // Show image picker dialog here
            },
            child: Text('Change profile image'),
          ),
          TextFormField(
            initialValue: user.name,
            decoration: InputDecoration(labelText: 'Name'),
            validator: (value) {
              if (value.isEmpty) {
                return 'Please enter a name';
              }
              return null;
            },
            onSaved: (value) {
              user.name = value;
            },
          ),
          TextFormField(
            initialValue: user.email,
            decoration: InputDecoration(labelText: 'Email'),
            validator: (value) {
              if (value.isEmpty || !value.contains('@')) {
                return 'Please enter a valid email';
              }
              return null;
            },
            onSaved: (value) {
              user.email = value;
            },
          ),
          RaisedButton(
            onPressed: () {
              if (_formKey.currentState.validate()) {
                _formKey.currentState.save();
                // Save the updated user information here
              }
            },
            child: Text('Save'),
          ),
        ],
      ),
    );
  }
}