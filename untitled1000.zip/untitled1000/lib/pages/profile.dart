class User {
  String name;
  String email;
  String profileImageUrl;

  User({required this.name, required this.email, required this.profileImageUrl});

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['name'] = this.name;
    data['email'] = this.email;
    data['profile_image_url'] = this.profileImageUrl;
    return data;
  }
}