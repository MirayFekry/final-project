import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatefulWidget {
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  String _meal = 'Breakfast';
  String _course = 'Main Dish';
  String _serving = '-5 mins';
  int _preparationTime = 0;
  int _calories = 2;

  final _meals = ['Breakfast', 'Dinner', 'Brunch', 'Lunch'];
  final _courses = ['Main Dish', 'Soup', 'Appetizer', 'Side', 'Starter', 'Dessert'];
  final _servings = ['-5 mins', '0 cal', '4', '20 mins', '500 cal'];

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        home: Scaffold(
        appBar: AppBar(
        title: Text('Filter'),
    ),
    body: Column(
    children: [
    Row(
    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
    children: [
    DropdownButton<String>(
    value: _meal,
    onChanged: (value) {
    setState(() {
    _meal = value!;
    });
    },
    items: _meals.map((String value) {
    return DropdownMenuItem<String>(
    value: value,
    child: Text(value),
    );
    }).toList(),
    ),
    DropdownButton<String>(
    value: _course,
    onChanged: (value) {
    setState(() {
    _course = value!;
    });
    },
    items: _courses.map((String value) {
    return DropdownMenuItem<String>(
    value: value,
    child: Text(value),
    );
    }).toList(),
    ),
    DropdownButton<String>(
    value: _serving,
    onChanged: (value) {
    setState(() {
    _serving = value!;
    });
    },
    items: _servings.map((String value) {
    return DropdownMenuItem<String>(
    value: value,
    child: Text(value),
    );
    }).toList(),
    ),
    ],
    ),
    Row(
    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
    children: [
    Text('Preparation Time'),
    SizedBox(width: 50),
    Text('Calories'),
    ],
    ),
    Row(
    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
    children: [
    Slider(
    value: _preparationTime.toDouble(),
    onChanged: (value) {
    setState(() {
    _preparationTime = value.toInt();
    });
    },
    min: 0,
    max: 60,
    divisions: 60,
    label: _preparationTime.toString(),
    ),
    Slider(
    value: _calories.toDouble(),
    onChanged: (value) {
    setState(() {
    _calories = value.toInt();
    });
    },
    min: 0,
    max: 1000,
    divisions: 10,
    label: _calories.toString(),
    ),
    ],
    ),
    ElevatedButton(
      child: Text('Apply'),

      onPressed: () {
    // Apply filter logic here
    },

      style: ElevatedButton.styleFrom(
        primary: Colors.orange,
        padding: EdgeInsets.symmetric(vertical: 15),
  ),
    ),
  ],
  ),
  ),
  );
}
}