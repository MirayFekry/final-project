import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Notifications Example',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: NotificationsPage(),
    );
  }
}

class NotificationsPage extends StatefulWidget {
  @override
  _NotificationsPageState createState() => _NotificationsPageState();
}

class _NotificationsPageState extends State<NotificationsPage> {
  List<String> _notifications = [
    '08 April\nLorem ipsum dolor sit amet, consetetur.',
    '08 April\nLorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut.',
    '08 April\nLorem ipsum dolor sit amet, consetetur.',
    '08 April\nLorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut.',
    'Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed tempor invidunt ut.',
  ];

  bool _showUnreadOnly = false;

  int _getUnreadCount() {
    return _notifications.where((notification) => !notification.startsWith('08 April')).length;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Notifications'),
        actions: [
          IconButton(
            icon: Icon(_showUnreadOnly ? Icons.done : Icons.clear),
            onPressed: () {
              setState(() {
                _showUnreadOnly = !_showUnreadOnly;
              });
            },
          ),
          SizedBox(width: 8),
        ],
      ),
      body: _notifications.isNotEmpty
          ? ListView.builder(
        itemCount: _notifications.length,
        itemBuilder: (context, index) {
          final notification = _notifications[index];
          final isUnread = !notification.startsWith('08 April');

          return Column(
            children: [
              if (_showUnreadOnly && !isUnread)
                Container(),
              if (!_showUnreadOnly || isUnread)
                ListTile(
                  title: Text(notification),
                  leading: CircleAvatar(
                    child: Text('${index + 1}'),
                  ),
                  trailing: IconButton(
                    icon: Icon(Icons.remove),
                    onPressed: () {
                      setState(() {
                        _notifications.removeAt(index);
                      });
                    },
                  ),
                ),
              if (_showUnreadOnly && isUnread)
                Divider(),
            ],
          );
        },
      )
          : Center(
        child: Text('No notifications'),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          setState(() {
            _notifications.add('New notification ${_notifications.length + 1}');
          });
        },
        child: Icon(Icons.add),
      ),
      bottomNavigationBar: BottomAppBar(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Text('${_getUnreadCount()} unread'),
            IconButton(
              icon: Icon(Icons.search),
              onPressed: () {
                // Show search dialog
              },
            ),
          ],
        ),
      ),
    );
  }
}