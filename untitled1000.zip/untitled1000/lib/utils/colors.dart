abstract class ColorsConst {
  static const int mainColor = 0xfff45b00;
  static const int containerBackgroundColor = 0xfff6f8fd;
  static const int titleColor = 0xff2097b3;
}
