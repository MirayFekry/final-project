abstract class Numbers {
  static const double appHorizontalPadding = 20.0;
}
