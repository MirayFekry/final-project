abstract class ImagesPath {
   static const String _path = "assets/images/";

   static String background = '${_path}background.jpg';
   static String baseHeader = '${_path}base_header.png';
}
