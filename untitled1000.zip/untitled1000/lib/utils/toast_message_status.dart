enum ToastMessageStatus { success, normal, failed }
