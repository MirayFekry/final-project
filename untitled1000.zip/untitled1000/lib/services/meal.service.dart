enum MealTypes { breakfast, launch, dinner }
